function App() {
  return <h1>APP</h1>;
}

export default App;
